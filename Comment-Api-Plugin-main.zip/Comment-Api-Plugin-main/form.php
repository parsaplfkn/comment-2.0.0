<div class="comments-section mt-4">
  <div class="container">
    <div class="row">
      <div class="col-12 comments-col">
        <?php if (get_comments_number() == 0) : ?> <div class="comments-title">اولین نفری باشید که برای این مطلب دیدگاهی بیان میکنید !
          </div>
        <?php else : ?>
          <div class="comments-title" id="cmtitle"><?php echo get_comments_number() ?> دیدگاه برای <?php echo the_title(); ?>
          </div>
          <h5 class="reply-to"></h5>
        <?php endif; ?>
        <?php if (comments_open()) : ?>
          <div class="mb-3" id='commentform'>
            <form action="<?php echo site_url() . '/wp-comments-post.php'; ?>" method="post">
              <div class="user-info d-flex justify-content-between">
                <?php if (!is_user_logged_in()) : ?>
                  <div class="mb-3">
                    <label for="name" class="form-label">نام: </label>
                    <input type="text" name="author" class="form-control" id="name" placeholder="اسم خود را وارد کنید">
                  </div>
                  <div class="mb-3">
                    <label for="mobile" class="form-label">شماره موبایل: (شماره شما نمایش داده نمیشود)</label>
                    <input type="number" name="mobile_number" class="form-control" id="mobile_number" placeholder="09*********">
                  </div>
              </div>
            <?php endif; ?>
            <div class="mt-2 col-lg-12">
              <label for="description" class="form-label">توضیحات: </label>
              <textarea class="form-control" name="comment" id="description" rows="5" placeholder="متن نظر خود را وارد کنید"></textarea>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-3">
              <input type="submit" name="submit" class="btn form-submit" value="ثبت نظر">
              <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID() ?>" id="comment_post_ID">
              <input type="hidden" name="comment_parent" id="comment_parent" value="0">
              <?php
              if (is_user_logged_in()) { ?>
                <input type="hidden" id="_wp_unfiltered_html_comment_disabled" name="_wp_unfiltered_html_comment" value="<?php echo wp_create_nonce() ?>">
              <?php }
              ?>
            </div>
            </form>
          </div>
        <?php else : ?>
          <div class="alret alret-info">ارسال دیدگاه برای این مطلب بسته شده است !</div>
        <?php endif; ?>
        <?php
        wp_list_comments(array(
          'style'      => 'ol',
          'callback' => 'ca_theme_comments',
          'short_ping'  => true,
        )); ?>

        <!-- <div class="comment-pagination">
          <?php paginate_comments_links() ?>
          <nav aria-label="Page navigation example">
            <ul class="pagination">
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li class="page-item "><a class="page-link active" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item">
                <a class="page-link" href="#" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>
        </div> -->
      </div>

    </div>
  </div>
</div>