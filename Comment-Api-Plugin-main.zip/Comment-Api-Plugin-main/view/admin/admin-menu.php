<?php

/**
 * Add a custom admin menu to display mobile numbers.
 */
function custom_admin_menu()
{
    add_users_page(
        'شماره های تماس',
        'شماره های تماس',
        'manage_options',
        'mobile_numbers_page',
        'display_mobile_numbers'
    );
}
add_action('admin_menu', 'custom_admin_menu');

/**
 * Display mobile numbers on the admin page with a styled table.
 */
function display_mobile_numbers()
{
?>
    <div class="wrap">
        <h1> شماره تماس های کامنت ها </h1>

        <?php
        // Query to retrieve all comments with mobile numbers
        $comments_query = new WP_Comment_Query(array('meta_query' => array(array('key' => 'mobile_number', 'compare' => 'EXISTS'))));
        $comments = $comments_query->comments;

        if ($comments) {
        ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>شماره تماس </th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($comments as $comment) : ?>
                        <?php $mobile_number = get_comment_meta($comment->comment_ID, 'mobile_number', true); ?>
                        <tr>
                            <td><?php echo esc_html($mobile_number); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php
        } else {
            echo '<p>No mobile numbers found.</p>';
        }
        ?>
    </div>
    <style>
        .wrap {
            max-width: 800px;
            margin: 20px auto;
        }

        table {
            direction: ltr;
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f5f5f5;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
<?php
}
