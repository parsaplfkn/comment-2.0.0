<?php
/*
Plugin Name: Comment Api Plugin
Plugin URI:  
Author:      ParsaPilafkan  
Author URI:  mailto:parsaplfkn@gmail.com
Version:     2.0.0
Description: A Plugin For Changing Comment Interface
*/
// Add mobile number field to the comment form

// For Direct Access 
defined('ABSPATH') || die;

// Defined Content
define('CA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CA_PLUGIN_URL', plugin_dir_url(__FILE__));
const CA_PLUGIN_ASSETS = CA_PLUGIN_DIR . 'assets/';
const CA_PLUGIN_ASSETS_URL = CA_PLUGIN_URL . 'assets/';

// Register Styles

function wpca_register_styles()
{
    // Register CSS
    wp_register_style('bootsrap-icons-css', CA_PLUGIN_ASSETS_URL . 'css/node_modules/bootstrap-icons/font/bootstrap-icons.css', '', '5.3.0');
    wp_register_style('bootsrap-liberery-css', CA_PLUGIN_ASSETS_URL . 'css/bootstrap.rtl.min.css', '', '5.3.0');
    wp_register_style('main-style', CA_PLUGIN_ASSETS_URL . 'css/main-style.css', '', '1.0.0');
    wp_enqueue_style('main-style');
    wp_enqueue_style('bootsrap-liberery-css');
    wp_enqueue_style('bootsrap-icons-css');

    // Register JS
    wp_register_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', '', '', true);
    wp_register_script('bootsrap-liberery-js', CA_PLUGIN_ASSETS_URL . 'js/bootstrap.bundle.min.js', '', '5.3.0', true);
    wp_register_script('main-js', CA_PLUGIN_ASSETS_URL . 'js/main-js.js', array('jquery'), '1.0.0', true);
    wp_register_script('replay-js', CA_PLUGIN_ASSETS_URL . 'js/replay.js', array('jquery'), '1.0.0', true);
    wp_register_script('ajax-js', CA_PLUGIN_ASSETS_URL . 'js/ajax.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('main-js');
    wp_enqueue_script('sweetalert2');
    wp_enqueue_script('ajax-js');
    wp_enqueue_script('replay-js');
    wp_enqueue_script('bootsrap-liberery-js');
    wp_localize_script('ajax-js', 'ca_ajax', [
        'ca_ajaxurl' => admin_url('admin-ajax.php'),
        '_ca_nonce' => wp_create_nonce(),
        '_ca_user_id' => get_current_user_id(),
    ]);
}
add_action('wp_enqueue_scripts', 'wpca_register_styles');

// Get Comment Theme Template
function custom_comments_template($template)
{
    if (is_singular() && comments_open() && !post_password_required()) {
        return CA_PLUGIN_DIR . 'form.php';
    }
}
add_filter('comments_template', 'custom_comments_template', 30);

// Includes
include_once 'inc/ca-theme-comment.php';
include_once 'inc/like-disslike.php';
include_once 'inc/save-mobile-number.php';
include_once 'view/admin/admin-menu.php';
