jQuery(document).ready(function ($) {
  //Comments reply
  jQuery(".reply").on("click", function (e) {
    // e.preventDefault();
    let el = jQuery(this);
    let commentID = el.data("commentid");
    let commentAuter = el.data("comment-auther");
    jQuery("#comment_parent").val(commentID);
    jQuery(".reply-to").text("در پاسخ به : " + commentAuter);
  });
});
