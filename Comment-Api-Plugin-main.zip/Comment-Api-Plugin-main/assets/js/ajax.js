jQuery(document).ready(function ($) {
  $(".like-button").on("click", function (e) {
    e.preventDefault();
    let el = jQuery(this);
    let comment_id = el.data("comment-id");
    let user_id = el.data("user-id");
    $.ajax({
      url: ca_ajax.ca_ajaxurl,
      type: "POST",
      dataType: "JSON",
      data: {
        action: "wp_ca_like_comment",
        comment_id: comment_id,
        user_id: user_id,
        _nonce: ca_ajax._ca_nonce,
      },

      success: function (response) {
        if (response) {
          Swal.fire(response.message, "", "success");
        }
        $(response.comment_class).text(response.like_count);
      },
      error: function (error) {
        if (error) {
          // alert(error.responseJSON.message);
          Swal.fire(error.responseJSON.message, "", "error");
        }
      },
    });
  });
});
jQuery(document).ready(function ($) {
  $(".dislike-button").on("click", function (e) {
    e.preventDefault();
    let el = jQuery(this);
    let comment_id = el.data("comment-id");
    let user_id = el.data("user-id");
    $.ajax({
      url: ca_ajax.ca_ajaxurl,
      type: "POST",
      dataType: "JSON",
      data: {
        action: "wp_ca_dislike_comment",
        comment_id: comment_id,
        user_id: user_id,
        _nonce: ca_ajax._ca_nonce,
      },

      success: function (response) {
        if (response) {
          Swal.fire(response.message, "", "success");
        }
        $(response.comment_class).text(response.dislike_count);
      },
      error: function (error) {
        if (error) {
          // alert(error.responseJSON.message);
          Swal.fire(error.responseJSON.message, "", "error");
        }
      },
    });
  });
});
