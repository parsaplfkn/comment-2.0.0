// var lClicks =0;
// var dClicks =0;
// var btn1 = document.querySelector('#green');
//   var btn2 = document.querySelector('#red');

//   btn1.addEventListener('click', function() {
//   if(!btn1.classList.contains('green')){
//      lClicks +=1 ;
//      } else {
//       lClicks -=1 ;
//      }
//       if (btn2.classList.contains('red')) {
        
//         btn2.classList.remove('red');
//         dClicks -= 1 ;
        
//       }
//     this.classList.toggle('green');
//     document.getElementById("l-counter").innerHTML = lClicks;
//     document.getElementById("ll-counter").innerHTML = dClicks;
//   });
  
//   btn2.addEventListener('click', function() {
//     if(btn2.classList.contains('red')){
//       dClicks -=1 ;
//     } else {
//       dClicks +=1 ;
//     }
//     if (btn1.classList.contains('green')) {
//       btn1.classList.remove('green');
//       lClicks -=1 ;
//     }
//     this.classList.toggle('red');
//     document.getElementById("l-counter").innerHTML = lClicks;
//     document.getElementById("ll-counter").innerHTML = dClicks;
//   });
        jQuery(document).ready(function($) {
            // Like button click event
            $('.comment-like').click(function(event) {
                event.preventDefault();
                var comment_id = $(this).data('comment-id');
                $.ajax({
                    type: 'post',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'comment_like',
                        comment_id: comment_id,
                        like: 1
                    },
                    success: function(response) {
                        alert(response);
                    }
                });
            });

            // Dislike button click event
            $('.comment-dislike').click(function(event) {
                event.preventDefault();
                var comment_id = $(this).data('comment-id');
                $.ajax({
                    type: 'post',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'comment_like',
                        comment_id: comment_id,
                        like: 0
                    },
                    success: function(response) {
                        alert(response);
                    }
                });
            });
        });

