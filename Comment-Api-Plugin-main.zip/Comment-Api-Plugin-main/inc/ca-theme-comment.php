<?php
function ca_theme_comments($comment, $args)
{
    $comment = $GLOBALS['comment'];
?>
    <?php if ($comment->comment_parent == 0) : ?>
        <ul id="comment-<?php echo $comment->comment_ID ?>" <?php comment_class('prev-comments mt-5 ') ?>>
            <li class="comment">
                <div class="comment-info mb-3">
                    <span class="comment-name me"><?php echo $comment->comment_author ?></span>
                </div>
                <?php if ($comment->comment_approved) : ?>
                    <p class="comment-des"><?php echo $comment->comment_content; ?></p>
                <?php else : ?>
                    <div class="alert alert-info">دیدگاه شما ارسال شد و پس از تایید مدیر در سایت مشاهده خواهد شد ! </div>
                <?php endif; ?>
                <div class="comment-extras">
                    <div class="date">
                        <span><?php echo get_comment_date() ?></span>
                    </div>

                    <div class="points">
                        <div class="score mt-2">
                            <span id="ll-counter" class="me-1 ll-counter <?php echo 'dlicommentid-' . $comment->comment_ID; ?>"><?php echo get_comment_meta($comment->comment_ID, 'ca_dislikes', true) ?: '0' ?></span> <i class="bi bi-hand-thumbs-down me-2 dislike-button " data-comment-id="<? echo $comment->comment_ID ?>" data-user-id="<?php echo get_current_user_ID() ?>" id="red">
                            </i>

                            <span id="l-counter" class="me-1 l-counter <?php echo 'licommentid-' . $comment->comment_ID; ?>"><?php echo get_comment_meta($comment->comment_ID, 'ca_likes', true) ?: '0' ?> </span><i class="bi bi-hand-thumbs-up like-button" data-comment-id="<? echo $comment->comment_ID ?>" data-user-id="<?php echo get_current_user_ID() ?>" id="green"></i>
                        </div>
                        <div class="comment-reply">
                            <a href='#cmtitle' data-comment-auther="<?php echo $comment->comment_author ?>" class="reply" data-commentID="<?php echo $comment->comment_ID ?>">پاسخ</a>
                        </div>
                    </div>
                </div>
            </li>
        <?php else : ?>
            <li id="comment-<?php echo $comment->comment_ID ?>" <?php comment_class('comment-reply') ?>>
                <div class="comment-info mb-3">
                    <span class="comment-name me"><?php echo $comment->comment_author ?></span>
                </div>
                <p class="comment-des"><?php echo $comment->comment_content; ?></p>
                <div class="comment-extras">
                    <div class="date">
                        <span> <?php echo get_comment_date() ?></span>
                    </div>
                    <div class="points">
                        <div class="score mt-2">
                            <span id="ll-counter" class="me-1 ll-counter <?php echo 'dlicommentid-' . $comment->comment_ID; ?>"><?php echo get_comment_meta($comment->comment_ID, 'ca_dislikes', true) ?: '0' ?></span> <i class="bi bi-hand-thumbs-down me-2 dislike-button " data-comment-id="<? echo $comment->comment_ID ?>" data-user-id="<?php echo get_current_user_ID() ?>" id="red">
                            </i>

                            <span id="l-counter" class="me-1 l-counter <?php echo 'licommentid-' . $comment->comment_ID; ?>"><?php echo get_comment_meta($comment->comment_ID, 'ca_likes', true) ?: '0' ?> </span><i class="bi bi-hand-thumbs-up like-button" data-comment-id="<? echo $comment->comment_ID ?>" data-user-id="<?php echo get_current_user_ID() ?>" id="green"></i>
                        </div>
                        <div class="comment-reply">
                            <a href='#cmtitle' data-comment-auther="<?php echo $comment->comment_author ?>" class="reply" data-commentID="<?php echo $comment->comment_ID ?>">پاسخ</a>
                        </div>
                    </div>
                </div>
            </li>
        <?php endif; ?>
        </ul>
    <?php
}



