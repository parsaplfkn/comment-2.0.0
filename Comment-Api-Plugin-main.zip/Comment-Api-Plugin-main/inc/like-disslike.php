<?php
//Add Like Logic
add_action('wp_ajax_wp_ca_like_comment', 'wp_ca_like_comment');
add_action('wp_ajax_nopriv_wp_ca_like_comment', 'wp_ca_like_comment');
function wp_ca_like_comment()
{
    if (isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])) {
        die('access denied !!!');
    };
    if (!is_user_logged_in()) {
        wp_send_json([
            'error' => true,
            'message' => 'لطفا ابتدا ورود کنید !',
        ], 403);
    }
    if (!empty($_POST['comment_id']) && !empty($_POST['user_id'])) {
        is_user_disliked_comment($_POST['user_id'], $_POST['comment_id']);
        is_user_liked_comment($_POST['user_id'], $_POST['comment_id']);

        $comment_id = intval($_POST['comment_id']);
        $user_id = intval($_POST['user_id']);
        if (!metadata_exists('user', $user_id, '_ca_cm_like_ids')) {
            $meta_value[] = $comment_id;
            add_user_meta($user_id, '_ca_cm_like_ids', $meta_value);
        } else {
            $current_meta_value = get_user_meta($user_id, '_ca_cm_like_ids', true);
            $current_meta_value[] = $comment_id;
            update_user_meta($user_id, '_ca_cm_like_ids', $current_meta_value,);
        }
        add_to_like_counter($comment_id);
        wp_send_json([
            'success' => true,
            'message' => 'با تشکر نظر شما ثبت شد',
            'like_count' => get_comment_meta($comment_id, 'ca_likes', true),
            'comment_class' => '.licommentid-' . $comment_id,


        ], 200);
    }
}
function is_user_liked_comment($user_id, $comment_id)
{
    $user_liked_comments = get_usermeta($user_id, '_ca_cm_like_ids', true);
    foreach ($user_liked_comments as $value) {
        if ($value == $comment_id) {
            wp_send_json([
                'error' => true,
                'message' => 'شما قبلا رای خود را ثبت کرده اید',
            ], 403);
        }
    }
}
function add_to_like_counter($comment_id)
{
    if (!metadata_exists('comment', $comment_id, 'ca_likes')) {
        add_comment_meta($comment_id, 'ca_likes', 1);
    } else {
        $likes_count = get_comment_meta($comment_id, 'ca_likes');
        $likes_count++;
        update_comment_meta($comment_id, 'ca_likes', $likes_count);
    }
}

// Add Dislike Logic
add_action('wp_ajax_wp_ca_dislike_comment', 'wp_ca_dislike_comment');
add_action('wp_ajax_nopriv_wp_ca_dislike_comment', 'wp_ca_dislike_comment');
function wp_ca_dislike_comment()
{
    if (isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])) {
        die('access denied !!!');
    };
    if (!is_user_logged_in()) {
        wp_send_json([
            'error' => true,
            'message' => 'لطفا ابتدا ورود کنید !',
        ], 403);
    }
    if (!empty($_POST['comment_id']) && !empty($_POST['user_id'])) {
        is_user_liked_comment($_POST['user_id'], $_POST['comment_id']);
        is_user_disliked_comment($_POST['user_id'], $_POST['comment_id']);

        $comment_id = intval($_POST['comment_id']);
        $user_id = intval($_POST['user_id']);
        if (!metadata_exists('user', $user_id, '_ca_cm_dislike_ids')) {
            $meta_value[] = $comment_id;
            add_user_meta($user_id, '_ca_cm_dislike_ids', $meta_value);
        } else {
            $current_meta_value = get_user_meta($user_id, '_ca_cm_dislike_ids', true);
            $current_meta_value[] = $comment_id;
            update_user_meta($user_id, '_ca_cm_dislike_ids', $current_meta_value,);
        }
        add_to_dislike_counter($comment_id);
        wp_send_json([
            'success' => true,
            'message' => 'با تشکر نظر شما ثبت شد',
            'dislike_count' => get_comment_meta($comment_id, 'ca_dislikes', true),
            'comment_class' => '.dlicommentid-' . $comment_id,

        ], 200);
    }
}
function is_user_disliked_comment($user_id, $comment_id)
{
    $user_disliked_comments = get_usermeta($user_id, '_ca_cm_dislike_ids', true);
    foreach ($user_disliked_comments as $value) {
        if ($value == $comment_id) {
            wp_send_json([
                'error' => true,
                'message' => 'شما قبلا رای خود را ثبت کرده اید',
            ], 403);
        }
    }
}
function add_to_dislike_counter($comment_id)
{
    if (!metadata_exists('comment', $comment_id, 'ca_dislikes')) {
        add_comment_meta($comment_id, 'ca_dislikes', 1);
    } else {
        $dislikes_count = get_comment_meta($comment_id, 'ca_dislikes');
        $dislikes_count++;
        update_comment_meta($comment_id, 'ca_dislikes', $dislikes_count);
    }
}
