<?php

function save_mobile_number_as_comment_meta($comment_id)
{
    // Get the mobile number from the comment form field
    $mobile_number = sanitize_text_field($_POST['mobile_number']);

    // If a mobile number is provided, save it as comment meta
    if (!empty($mobile_number)) {
        add_comment_meta($comment_id, 'mobile_number', $mobile_number, true);
    }
}

// Hook into the comment submission process
add_action('comment_post', 'save_mobile_number_as_comment_meta');
